<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Opositore extends Model
{
    protected $guarded = [];
}
