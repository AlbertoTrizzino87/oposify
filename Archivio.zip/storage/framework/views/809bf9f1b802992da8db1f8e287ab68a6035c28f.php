<?php $__env->startSection('content'); ?>
<main id=login>
    <header class="header">
			<div id="logo">
				<a href="<?php echo e(URL('/')); ?>"><img src="img/Logo-TuOposify-negro.png" title="logotipo" alt="Logotipo tuOposify"></a>
			</div>
			<span class="icon-hamburguesa" id="trigger-home"></span>
		</header>

    <nav class="nav">
        <div class="botones">
			<a href="<?php echo e(route('register')); ?>" id=""><?php echo e(__('Registrate')); ?></a>
            <a href="<?php echo e(route('login')); ?>" id="login-trigger"><?php echo e(__('Acceder')); ?></a>
        </div>
    </nav>

    <div class="menu-mobile">
			<a href="<?php echo e(route('register')); ?>" id="signup-trigger" class="link"><?php echo e(__('Registrate')); ?></a>
			<?php if(auth()->guard()->guest()): ?>
			<a href="<?php echo e(route('login')); ?>" id="login-trigger" class="link"><?php echo e(__('Acceder')); ?></a>
			<?php else: ?>
			<a id="navbarDropdown" class="nav-link dropdown-toggle link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(__('Mi perfil')); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
			<?php endif; ?>
    </div>
        
    <div class="login-container">
    <div class="login">
         <h1><?php echo e(__('Acceder')); ?></h1>
            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                 <input id="email" type="email"  name="email" value="<?php echo e(old('email')); ?>" placeholder="Correo" required autofocus><br>
                        <?php if($errors->has('email')): ?>
                             <span class="invalid-feedback">
                                 <strong><?php echo e($errors->first('email')); ?></strong>
                             </span>
                         <?php endif; ?>
                 <input id="password" type="password"  name="password" placeholder="Contraseña" required><br>
                         <?php if($errors->has('password')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                <div class="mantener">
                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>><span> <?php echo e(__('Mantener session')); ?><span><br>
                </div>
                <div class="darle-boton">
                <button type="submit" class="boton-acceder">
                     <?php echo e(__('Acceder')); ?>

                </button>
                <a class="pss-olvidada" href="<?php echo e(route('password.request')); ?>">
                     <?php echo e(__('¿Contraseña olvidada?')); ?>

                 </a>
                </div>
              </form>
            </div>
         </div>
<main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>