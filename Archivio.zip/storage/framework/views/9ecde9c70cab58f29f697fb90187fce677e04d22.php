<?php $__env->startSection('content'); ?>
<main id="reset">
    <header class="header">
		<div id="logo">
			<a href="index.php"><img src="../img/Logo-TuOposify-negro.png" title="logotipo" alt="Logotipo tuOposify"></a>
		</div>
		<span class="icon-hamburguesa" id="trigger-home"></span>
	</header>

    <nav class="nav">
        <div class="botones">
			<a href="<?php echo e(route('register')); ?>" id=""><?php echo e(__('Registrate')); ?></a>
            <a href="<?php echo e(route('login')); ?>" id="login-trigger"><?php echo e(__('Acceder')); ?></a>
        </div>
    </nav>

    <div class="menu-mobile">
			<a href="<?php echo e(route('register')); ?>" id="signup-trigger" class="link"><?php echo e(__('Registrate')); ?></a>
			<?php if(auth()->guard()->guest()): ?>
			<a href="<?php echo e(route('login')); ?>" id="login-trigger" class="link"><?php echo e(__('Acceder')); ?></a>
			<?php else: ?>
			<a id="navbarDropdown" class="nav-link dropdown-toggle link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(__('Mi perfil')); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
			<?php endif; ?>
    </div>

<div class="reset">
        <div class="reset-pssw">
            <h1><?php echo e(__('cambiar contraseña')); ?></h1>
            <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

            <form method="POST" action="<?php echo e(route('password.email')); ?>">
                        <?php echo csrf_field(); ?>
                <label for="email"><?php echo e(__('Dirección de correo')); ?></label>
                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>
                     <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                     <?php endif; ?>
                        <button type="submit">
                            <?php echo e(__('Enviar link de reseteo')); ?>

                         </button>
                    </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>