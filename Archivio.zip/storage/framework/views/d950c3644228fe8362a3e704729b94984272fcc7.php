<?php $__env->startSection('title'); ?>
	<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<main id='<?php echo e($main); ?>'>
		<header class="header">
			<img src="<?php echo e(Storage::disk('public')->url(Auth::user()->image)); ?>"  class="foto-user">
			<div id="logo">
				<a href="<?php echo e(url('/user')); ?>"><img src="img/Logo-TuOposify-negro.png" title="logotipo" alt="Logotipo tuOposify"></a>     
			</div>
			<span class="icon-hamburguesa" id="trigger-home"></span>
			<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();" id="close-user"><span class="icon-logout"></span></a>
					 <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                     </form>
		</header>

		<nav class="nav">
			<div class="nav-top">
            	<img src="<?php echo e(Storage::disk('public')->url(Auth::user()->image)); ?>"  alt="">
				<h1><?php echo e(Auth::user()->name); ?> </h1>
			</div>
           
			<div class="botones">
			<a href="#" id="clases-trigger">clases</a>
			<a href="#" id="temario-trigger">temario</a>
			<a href="#" id="apuntes-trigger">apuntes</a>
			<a href="#" id="test-trigger">test</a>
			<a href="#" id="mensajes-trigger">mensajes</a>
			<a href="#" id="diario-trigger">diario</a>
			<a href="#" id="buscar-trigger">buscar curso</a>
			<a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                     document.getElementById('logout-form').submit();"><?php echo e(__('Cerrar sessión')); ?></a>
					<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                     </form>
		</nav> 

		<div class="menu-mobile">
			<span class="icon-play-button" id="clases-mobile-trigger"></span>
			<span class="icon-books-stack-of-three" id="temario-mobile-trigger"></span>
			<span class="icon-contract" id="apuntes-mobile-trigger"></span>
			<span class="icon-exam" id="test-mobile-trigger"></span>
			<span class="icon-paper-plane" id="mensajes-mobile-trigger"></span>
			<span class="icon-quill-drawing-a-line" id="diario-mobile-trigger"></span>
			<span class="icon-lupa" id="buscar-mobile-trigger"></span>
		</div>

		<div class="container-fluid feeds">
			<div class="row">
				<div class="fila col-12 col-lg-4">
					<div class="block desaparecer">
						<h3><?php echo e($title_home['uno']); ?></h3>
					</div>
					<div class="block desaparecer">
						<h3><?php echo e($title_home['cuatro']); ?></h3>
					</div>
				</div>
				<div class="fila col-12 col-lg-4">
					<div class="block">
						<h3><?php echo e($title_home['dos']); ?></h3>
					</div>
					<div class="block">
						<h3><?php echo e($title_home['cinco']); ?></h3>
					</div>
				</div>
				<div class="fila col-12 col-lg-4">
					<div class="full-block">
						<h3><?php echo e($title_home['tres']); ?></h3>
					</div>
				</div>
			</div>
		</div>


       <section class="contenido" id="clases">
			<div class="cabezera">
				<span class="icon-cross" id="close-clases"></span>
				<form action="buscar.php" method="POST">
					<input type="text" name="parametro" placeholder="Buscar clase">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>clases</h3>
			<div class="box">
				<div class="content-box">
					<ul class="nav nav-tabs" id="videoTab" role="tablist">
						<?php $__empty_1 = true; $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<li class="nav-item"><a id="<?php echo e($id->curso); ?>-tab" href="#<?php echo e($id->curso); ?>" data-toggle="tab" role="tab" aria-controls="home" aria-selected="<?php echo e($id->curso); ?>"><?php echo e($id->curso); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<span>No hay cursos disponibles</span>
						<?php endif; ?>
					</ul>
					<div class="tab-content" id="videoTabContent">
						<?php $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane" id="<?php echo e($id->curso); ?>" role="tabpanel" aria-labelledby="<?php echo e($id->curso); ?>-tab">
								<div class="container">
									<div class="row">
										<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($video->curso_id == $id->curso_id): ?>
											<div class="col-md-3 col-lg-4">
													<video controls>
														<source src="<?php echo e(Storage::disk('public')->url($video->video)); ?>" type="video/mp4">
													</video>
													<h5><?php echo e($video->titulo); ?></h5>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</div>
				</div>
			</div>
		</section>
		
		<section class="contenido" id="temario">
			<div class="cabezera">
				<span class="icon-cross" id="close-temario"></span>
				<form action="buscar.php" method="POST">
					<input type="text" name="parametro" placeholder="Buscar tema">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>temario</h3>
			<div class="box">
				<div class="content-box">
					<ul class="nav nav-tabs" id="videoTab" role="tablist">
						<?php $__empty_1 = true; $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<li class="nav-item"><a id="<?php echo e($id->curso); ?>-tab" href="#2<?php echo e($id->curso); ?>" data-toggle="tab" role="tab" aria-controls="home" aria-selected="<?php echo e($id->curso); ?>"><?php echo e($id->curso); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<span>No hay cursos disponibles</span>
						<?php endif; ?>
					</ul>
					<div class="tab-content" id="videoTabContent">
						<?php $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane" id="2<?php echo e($id->curso); ?>" role="tabpanel" aria-labelledby="<?php echo e($id->curso); ?>-tab">
								<div class="container">
									<div class="row">
										<?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($tema->curso_id == $id->curso_id): ?>
											<div class="col-md-3 col-lg-4">
													<div>
														<a href="<?php echo e(Storage::disk('public')->url($tema->tema)); ?>" target="_blank"><span class="icon-books-stack-of-three"></span></a>
													</div>
													<h5><?php echo e($tema->titulo); ?></h5>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</div>
				</div>
			</div>
		</section>
		
		<section class="contenido" id="apuntes">
			<div class="cabezera">
				<span class="icon-cross" id="close-apuntes"></span>
				<form action="buscar.php" method="POST">
					<input type="text" name="parametro" placeholder="Buscar apuntes">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>apuntes</h3>
			<div class="anadir-curso">
				<span id="new-apunte">subir apuntes</span>
			</div>
			<div class="box">
				<div class="content-box">
					<ul class="nav nav-tabs" id="videoTab" role="tablist">
						<?php $__empty_1 = true; $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<li class="nav-item"><a id="<?php echo e($id->curso); ?>-tab" href="#5<?php echo e($id->curso); ?>" data-toggle="tab" role="tab" aria-controls="home" aria-selected="<?php echo e($id->curso); ?>"><?php echo e($id->curso); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<span>No hay apuntes disponibles</span>
						<?php endif; ?>
					</ul>
					<div class="tab-content" id="videoTabContent">
						<?php $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane" id="5<?php echo e($id->curso); ?>" role="tabpanel" aria-labelledby="<?php echo e($id->curso); ?>-tab">
								<div class="container">
									<div class="row">
										<?php $__currentLoopData = $apuntes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apunte): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($apunte->curso_id == $id->curso_id): ?>
											<div class="col-md-3 col-lg-4">
													<div>
														<a href="<?php echo e(Storage::disk('public')->url($apunte->apuntes)); ?>" target="_blank"><span class="icon-books-stack-of-three"></span></a>
													</div>
													<h5><?php echo e($apunte->titulo); ?></h5>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</div>
				</div>
			</div>
		</section>

		<section class="add-to-db" id="add-apunte">
			<span class="icon-cross" id="close-add-apunte"></span>
			<div class="add-content">
			<form action="/user/apunte-creado" method="POST" enctype="multipart/form-data">
				<?php echo e(csrf_field()); ?>

				<label for="oposicion">Elegir el curso</label>
				<select name="oposicion">
				<?php $__empty_1 = true; $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<option value="<?php echo e($id->curso_id); ?>"><?php echo e($id->curso); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<option value="">No hay cursos disponibles</option>
				<?php endif; ?>
				</select>
				<label for="titulo" id="apunte">Titulo</label>
				<input type="text" name="titulo" id="">
				<label for="apuntes">Subir apuntes - formato PDF</label>
				<input type="file" name="apuntes" id="">
				<input type="submit" value="Subir apuntes" name="subirApunte">
			</form>
			</div>
		</section>
		
		<section class="contenido" id="test">
			<div class="cabezera">
				<span class="icon-cross" id="close-test"></span>
				<form action="buscar.php" method="POST">
					<input type="text" name="parametro" placeholder="Buscar test">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>test</h3>
			<div class="box">
				<div class="content-box">
					<ul class="nav nav-tabs" id="videoTab" role="tablist">
						<?php $__empty_1 = true; $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
							<li class="nav-item"><a id="<?php echo e($id->curso); ?>-tab" href="#3<?php echo e($id->curso); ?>" data-toggle="tab" role="tab" aria-controls="home" aria-selected="<?php echo e($id->curso); ?>"><?php echo e($id->curso); ?></a></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<span>No hay cursos disponibles</span>
						<?php endif; ?>
					</ul>
					<div class="tab-content" id="videoTabContent">
						<?php $__currentLoopData = $opositorId; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="tab-pane" id="3<?php echo e($id->curso); ?>" role="tabpanel" aria-labelledby="<?php echo e($id->curso); ?>-tab">
								<div class="container">
									<div class="row">
										<?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($test->curso_id == $id->curso_id): ?>
											<div class="col-md-3 col-lg-4">
													<div>
														<a href="<?php echo e(Storage::disk('public')->url($test->test)); ?>" target="_blank"><span class="icon-exam"></span></a>
													</div>
													<h5><?php echo e($test->titulo); ?></h5>
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
									</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
					</div>
				</div>
			</div>
		</section>
		
		<section class="contenido" id="mensajes">
			<div class="cabezera">
				<span class="icon-cross" id="close-mensajes"></span>
				<form action="buscar.php" method="POST">
					<input type="text" name="parametro" placeholder="Buscar mensaje">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>mensajes</h3>
			<div class="anadir-curso">
				<span id="new-mensajes">nuevo mensaje</span>
			</div>
		</section>

		<section class="add-to-db" id="add-mensajes">
			<span class="icon-cross" id="close-add-mensajes"></span>
		</section>
		
		<section class="contenido" id="diario">
			<div class="cabezera">
				<span class="icon-cross" id="close-diario"></span>
				<form action="buscar.php" method="POST">
				<input type="text" name="parametro" placeholder="Buscar entrada">
					<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<h3>diario</h3>
			<div class="anadir-curso">
				<span id="new-diario">añadir entrada</span>
			</div>
        </section>

		<section class="add-to-db" id="add-diario">
			<span class="icon-cross" id="close-add-diario"></span>
		</section>

		<section class="contenido" id="buscar">
			<div class="cabezera">
				<span class="icon-cross" id="close-buscar"></span>
				<form action="/buscar" method="GET">
				<input type="text" name="parametro" placeholder="Buscar preparador,academia u oposición">
				<input type="submit" name="buscar" value="Buscar">
				</form>
			</div>
			<div class="resultados">
					<?php $__empty_1 = true; $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<div class="busqueda-layout">
							 	<div class="layout-left col-md-2">
							 		<img src="<?php echo e(Storage::disk('public')->url($resultado->user->image)); ?>" alt="">
								 	<?php if(empty($resultado->user->apellido)): ?>
								 	<span><?php echo e($resultado->user->name); ?></span>
								 	<?php elseif(empty($resultado->user->apellidoDos)): ?>
								 	<span><?php echo e($resultado->user->name); ?> <?php echo e($resultado->user->apellido); ?></span>
								 	<?php else: ?> 
								 	<span><?php echo e($resultado->user->name); ?> <?php echo e($resultado->user->apellido); ?> <br> <?php echo e($resultado->user->apellidoDos); ?></span>
								 	<?php endif; ?>
								</div>
								<div class="layout-center col-md-7">
									<h5><?php echo e($resultado->oposicione->descripcion); ?></h5>
									<p><?php echo e($resultado->descripcion); ?></p>
								</div>
								<div class="layout-right col-md-3">
									<span><?php echo e($resultado->precio); ?>€</span>
									<form action="<?php echo URL::to('paypal'); ?>" method="POST" id="payment-form">
										<?php echo e(csrf_field()); ?>

										<input type="text" name="amount" id="amount" value="<?php echo e($resultado->precio); ?>" hidden>
										<input type="text" name="idPreparador" id="idPreparador" value="<?php echo e($resultado->user_id); ?>" hidden>
										<input type="text" name="nombreCurso" id="nombreCurso" value="<?php echo e($resultado->oposicione->descripcion); ?>" hidden>
										<input type="text" name="idCurso" id="idCurso" value="<?php echo e($resultado->id); ?>" hidden>
										<button>comprar</button>
									</form>
								</div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						
					<?php endif; ?>
				</div>
        </section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>