<?php $__env->startSection('content'); ?>

<main id="register">

    <header class="header">
			<div id="logo" class="logo">
				<a href="<?php echo e(URL('/')); ?>"><img src="img/Logo-TuOposify-negro.png" title="logotipo" alt="Logotipo tuOposify"></a>
			</div>
			<span class="icon-hamburguesa" id="trigger-home"></span>
    </header>
    
    <nav class="nav">
        <div class="botones">
            <a href="<?php echo e(route('register')); ?>" id="signup-trigger"><?php echo e(__('Registrate')); ?></a>
            <a href="<?php echo e(route('login')); ?>" id="login-trigger"><?php echo e(__('Acceder')); ?></a>
        </div>
    </nav>

    <div class="menu-mobile">
			<a href="<?php echo e(route('register')); ?>" id="signup-trigger" class="link"><?php echo e(__('Registrate')); ?></a>
			<?php if(auth()->guard()->guest()): ?>
			<a href="<?php echo e(route('login')); ?>" id="login-trigger" class="link"><?php echo e(__('Acceder')); ?></a>
			<?php else: ?>
			<a id="navbarDropdown" class="nav-link dropdown-toggle link" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(__('Mi perfil')); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
			<?php endif; ?>
		</div>

    <div class="signup-container">
        <div class="signup">
        <h1><?php echo e(__('Registrate')); ?></h1>
                    <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>

                        <select name="role" id="form-trigger">
                            <option value="Academia">Academia</option>
				            <option value="Preparador">Preparador</option>
                            <option value="Opositor">Opositor</option>     
                        </select>

                         <?php if($errors->has('role')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('role')); ?></strong>
                            </span>
                        <?php endif; ?>
                        
                        <input id="name" type="text"  name="name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" required autofocus>
                                <?php if($errors->has('name')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        
                         <input id="apellido" type="text" style="display:none;"  name="apellido" value="<?php echo e(old('apellido')); ?>" class="escondido" placeholder="Primer Apellido">
                                <?php if($errors->has('apellido')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('apellido')); ?></strong>
                                    </span>
                                <?php endif; ?>

                         <input id="apellidoDos" type="text" style="display:none;"  name="apellidoDos" value="<?php echo e(old('apellidoDos')); ?>" class="escondido" placeholder="Segundo Apellido">
                                <?php if($errors->has('apellidoDos')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('apellidoDos')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        <input id="telefono" type="text"  name="telefono" value="<?php echo e(old('telefono')); ?>" placeholder="Telefono">
                        <?php if($errors->has('telefono')): ?>
                            <span class="invalid-feedback">
                                <strong><?php echo e($errors->first('telefono')); ?></strong>
                            </span>
                        <?php endif; ?>

                        <input id="ciudad" type="text"  name="ciudad" value="<?php echo e(old('ciudad')); ?>" placeholder="Ciudad">

                        <input id="direccion" type="text"  name="direccion" value="<?php echo e(old('direccion')); ?>" placeholder="Dirección">
           
                         <input id="email" type="email"  name="email" value="<?php echo e(old('email')); ?>" placeholder="correo" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                           
                        <input id="password" type="password"  name="password" placeholder="Contraseña" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>

                        <input id="password-confirm" type="password"  name="password_confirmation"  placeholder="Repetir Contraseña" required><br>

                        <label for="image">Subir foto de perfil</label><br>

                        <input type="file" name="image" class="form-control-file" id="image">
                            
                        <button type="submit">
                             <?php echo e(__('Registrate')); ?>

                        </button>
                    </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>