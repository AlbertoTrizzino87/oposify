<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <?php echo $__env->yieldContent('meta'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="https://fonts.googleapis.com/css?family=Roboto|Roboto+Condensed:700" rel="stylesheet">
    <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet"> -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/estilo.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/fonts.css')); ?>" />
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    
	<title><?php echo $__env->yieldContent('title','TuOposify_home'); ?></title>
</head>
<body>	

        <?php echo $__env->yieldContent('content'); ?>
 
  <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/function.js')); ?>"></script>
  <script type="text/javascript" src="<?php echo e(URL::asset('js/responsive.js')); ?>"></script>
</body>
</html>